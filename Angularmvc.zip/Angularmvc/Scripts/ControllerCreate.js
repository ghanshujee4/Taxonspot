﻿//var app = angular.module('myApp', []);
//app.controller('HomeCtrl', ['$scope', '$http', function ($scope, $http) {
//    $scope.message = "Welcome to Angular .NET MVC 4";
//    $http.post("/Acount/CreateEmployees", { routineId: data }).error(function (responseData) {
//        console.log("Error !" + responseData);
//    });
//    $scope.addRow = function () {
//        debugger;
//        $scope.companies.push({ 'name': $scope.name, 'salary': $scope.salary, 'dob': $scope.dob, 'employees': $scope.employees, 'headoffice': $scope.headoffice });
//        $scope.name = '';
//        $scope.salary = '';
//        $scope.dob = '';
//        $scope.employees = '';
//        $scope.headoffice = '';
//    };
//}]);