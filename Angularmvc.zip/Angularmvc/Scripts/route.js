﻿angular.module('helloApp', ['ngRoute', 'ngResource']);
function TwitterCtrl($scope, $resource) {
}